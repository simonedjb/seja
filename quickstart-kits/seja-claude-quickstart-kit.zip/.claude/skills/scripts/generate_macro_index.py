#!/usr/bin/env python3
"""
generate_macro_index.py — Unified artifact index generator.

Recursively scans all .md files in the project's OUTPUT_DIR and subfolders,
extracts metadata (date, type, title) from each file's header, and generates
OUTPUT_DIR/INDEX.md with all artifacts sorted chronologically (oldest first).

The output directory is read from project-conventions.md (the OUTPUT_DIR
variable), making this script portable across any SEJA-bootstrapped project.

Usage
-----
    python .claude/skills/scripts/generate_macro_index.py
    python .claude/skills/scripts/generate_macro_index.py --verbose

Run from the repository root.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from project_config import REPO_ROOT, get_path

OUTPUT_DIR = get_path("OUTPUT_DIR") or REPO_ROOT / "_output"
INDEX_FILE = OUTPUT_DIR / "INDEX.md"

# Files to exclude from indexing (basenames)
EXCLUDED_FILES = {
    "INDEX.md",
    "briefs.md",
    "briefs-index.md",
    "update-tests-tracker.md",
}


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate text to max_len, appending ellipsis if needed."""
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "\u2026"


# ---------------------------------------------------------------------------
# Date extraction helpers
# ---------------------------------------------------------------------------
_DATETIME_RE = re.compile(r"(\d{4}-\d{2}-\d{2}[\s]+\d{2}:\d{2}(?::\d{2})?(?:\s*UTC)?)")
_DATE_ONLY_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")
_FILENAME_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")


def _normalize_date(date_str: str) -> str:
    """Normalize a date string for consistent sorting."""
    date_str = date_str.strip()
    # Pad to full datetime if only date
    if len(date_str) == 10:  # YYYY-MM-DD
        return date_str + " 00:00:00 UTC"
    return date_str


# ---------------------------------------------------------------------------
# Extractors for known artifact types
# ---------------------------------------------------------------------------

# Plan (done): # DONE | datetime | Plan NNNN | PREFIX-SCOPE | datetime | title
_PLAN_DONE_RE = re.compile(
    r"^#\s+DONE\s*\|\s*([\d\-: UTC]+)\s*\|\s*Plan\s+(\d+)\s*\|\s*(\S+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*([^|]+)",
    re.IGNORECASE,
)

# Plan (open): # Plan NNNN | PREFIX-SCOPE | datetime | title
_PLAN_OPEN_RE = re.compile(
    r"^#\s+Plan\s+(\d+)\s*\|\s*(\S+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*([^|]+)",
    re.IGNORECASE,
)

# Plan (alt done): # Plan NNNN | DONE | PREFIX-SCOPE | datetime | title
_PLAN_ALT_DONE_RE = re.compile(
    r"^#\s+Plan\s+(\d+)\s*\|\s*DONE\s*\|\s*(\S+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*([^|]+)",
    re.IGNORECASE,
)

# Advisory: # Advisory NNNN | PREFIX-SCOPE | datetime | title
_ADVISORY_RE = re.compile(
    r"^#\s+Advisory\s+(\d+)\s*\|\s*(\S+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*(.+)",
    re.IGNORECASE,
)

# Roadmap: # Roadmap NNNN | datetime | title
_ROADMAP_RE = re.compile(
    r"^#\s+Roadmap\s+(\d+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*(.+)",
    re.IGNORECASE,
)

# QA Session: # QA Session - datetime  (em dash or hyphen)
_QA_SESSION_RE = re.compile(
    r"^#\s+QA\s+Session\s*[\u2014\-]+\s*([\d\-: UTC]+)",
    re.IGNORECASE,
)

# QA Log (plan) with pipe: # QA Log | Plan NNNN | title  OR  # QA Log | execute-plan NNNN, NNNN
_QA_LOG_PLAN_PIPE_RE = re.compile(
    r"^#\s+QA\s+Log\s*\|\s*(?:execute-plan\s+)?(?:Plan\s+)?(\d[\d\-,\s]*)(?:\s*\|\s*(.+))?\s*$",
    re.IGNORECASE,
)

# QA Log (plan) with dash/em-dash: # QA Log — Plan NNNN — title
_QA_LOG_PLAN_DASH_RE = re.compile(
    r"^#\s+QA\s+Log\s*[\u2014\-]+\s*(?:Post-skill\s+for\s+)?(?:Plan[s]?\s+)?(\d[\d\-,\s]*)\s*[\u2014\-]+\s*(.+)",
    re.IGNORECASE,
)

# QA Log (skill): # QA Log | skill | brief
_QA_LOG_SKILL_RE = re.compile(
    r"^#\s+QA\s+Log\s*\|\s*(\S+)\s*\|\s*(.+)",
    re.IGNORECASE,
)

# QA Log generic (catch-all for variations like "Post-skill for Plans")
_QA_LOG_GENERIC_RE = re.compile(
    r"^#\s+QA\s+Log\s*[\u2014\-|:]+\s*(.+)",
    re.IGNORECASE,
)

# Metacomm: # Metacommunication Message — title  OR  # Metacommunication Message (subtitle)
_METACOMM_RE = re.compile(
    r"^#\s+Metacommunication\s+Message\s*(?:[\u2014\-]+\s*)?(.+)",
    re.IGNORECASE,
)


def _find_date_in_text(text: str) -> str | None:
    """Try to find a date in the first 10 lines of text."""
    for line in text.split("\n")[:10]:
        m = _DATETIME_RE.search(line)
        if m:
            return m.group(1).strip()
    for line in text.split("\n")[:10]:
        m = _DATE_ONLY_RE.search(line)
        if m:
            return m.group(1).strip()
    return None


def _find_date_in_filename(filename: str) -> str | None:
    """Try to extract a date from filename."""
    m = _FILENAME_DATE_RE.search(filename)
    if m:
        return m.group(1).strip()
    return None


def extract_artifact(filepath: Path) -> dict | None:
    """Extract artifact metadata from a markdown file."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    # Find the first heading line
    header_line = ""
    for line in text.split("\n")[:5]:
        stripped = line.strip()
        if stripped.startswith("#"):
            header_line = stripped
            break

    if not header_line:
        return None

    rel_path = filepath.relative_to(OUTPUT_DIR)

    # Try each known pattern

    # Plan (done)
    m = _PLAN_DONE_RE.match(header_line)
    if m:
        status = "DONE"
        plan_id = m.group(2).strip().zfill(4)
        is_qa = filepath.name.startswith("plan-qa-")
        return {
            "date": _normalize_date(m.group(4).strip()),
            "type": "Plan QA" if is_qa else "Plan",
            "id": plan_id,
            "title": truncate(m.group(5).strip().rstrip("|").strip()),
            "status": status,
            "file": str(rel_path),
        }

    # Plan (alt done): # Plan NNNN | DONE | PREFIX-SCOPE | datetime | title
    m = _PLAN_ALT_DONE_RE.match(header_line)
    if m:
        plan_id = m.group(1).strip().zfill(4)
        is_qa = filepath.name.startswith("plan-qa-")
        return {
            "date": _normalize_date(m.group(3).strip()),
            "type": "Plan QA" if is_qa else "Plan",
            "id": plan_id,
            "title": truncate(m.group(4).strip().rstrip("|").strip()),
            "status": "DONE",
            "file": str(rel_path),
        }

    # Plan (open)
    m = _PLAN_OPEN_RE.match(header_line)
    if m:
        plan_id = m.group(1).strip().zfill(4)
        is_qa = filepath.name.startswith("plan-qa-")
        return {
            "date": _normalize_date(m.group(3).strip()),
            "type": "Plan QA" if is_qa else "Plan",
            "id": plan_id,
            "title": truncate(m.group(4).strip().rstrip("|").strip()),
            "status": "OPEN",
            "file": str(rel_path),
        }

    # Advisory
    m = _ADVISORY_RE.match(header_line)
    if m:
        return {
            "date": _normalize_date(m.group(3).strip()),
            "type": "Advisory",
            "id": m.group(1).strip().zfill(4),
            "title": truncate(m.group(4).strip().rstrip("|").strip()),
            "status": "DONE",
            "file": str(rel_path),
        }

    # Roadmap
    m = _ROADMAP_RE.match(header_line)
    if m:
        return {
            "date": _normalize_date(m.group(2).strip()),
            "type": "Roadmap",
            "id": m.group(1).strip().zfill(4),
            "title": truncate(m.group(3).strip().rstrip("|").strip()),
            "status": "DONE",
            "file": str(rel_path),
        }

    # QA Session
    m = _QA_SESSION_RE.match(header_line)
    if m:
        return {
            "date": _normalize_date(m.group(1).strip()),
            "type": "QA Session",
            "id": "",
            "title": truncate(header_line.lstrip("# ").strip()),
            "status": "",
            "file": str(rel_path),
        }

    # QA Log (plan, pipe separator)
    m = _QA_LOG_PLAN_PIPE_RE.match(header_line)
    if m:
        date = _find_date_in_text(text) or _find_date_in_filename(filepath.name) or ""
        title_raw = m.group(2).strip().rstrip("|").strip() if m.group(2) else f"QA for plan {m.group(1).strip()}"
        return {
            "date": _normalize_date(date) if date else "",
            "type": "QA Log",
            "id": m.group(1).strip(),
            "title": truncate(title_raw),
            "status": "",
            "file": str(rel_path),
        }

    # QA Log (plan, dash/em-dash separator)
    m = _QA_LOG_PLAN_DASH_RE.match(header_line)
    if m:
        date = _find_date_in_text(text) or _find_date_in_filename(filepath.name) or ""
        return {
            "date": _normalize_date(date) if date else "",
            "type": "QA Log",
            "id": m.group(1).strip(),
            "title": truncate(m.group(2).strip().rstrip("|").strip()),
            "status": "",
            "file": str(rel_path),
        }

    # QA Log (skill)
    m = _QA_LOG_SKILL_RE.match(header_line)
    if m:
        date = _find_date_in_text(text) or _find_date_in_filename(filepath.name) or ""
        return {
            "date": _normalize_date(date) if date else "",
            "type": "QA Log",
            "id": "",
            "title": truncate(m.group(2).strip().rstrip("|").strip()),
            "status": "",
            "file": str(rel_path),
        }

    # QA Log (generic catch-all)
    m = _QA_LOG_GENERIC_RE.match(header_line)
    if m:
        date = _find_date_in_text(text) or _find_date_in_filename(filepath.name) or ""
        return {
            "date": _normalize_date(date) if date else "",
            "type": "QA Log",
            "id": "",
            "title": truncate(m.group(1).strip().rstrip("|").strip()),
            "status": "",
            "file": str(rel_path),
        }

    # Metacomm
    m = _METACOMM_RE.match(header_line)
    if m:
        date = _find_date_in_text(text) or _find_date_in_filename(filepath.name) or ""
        return {
            "date": _normalize_date(date) if date else "",
            "type": "Metacomm",
            "id": "",
            "title": truncate(m.group(1).strip()),
            "status": "",
            "file": str(rel_path),
        }

    # Fallback: try to extract date from text or filename
    date = _find_date_in_text(text) or _find_date_in_filename(filepath.name)
    if date:
        title = header_line.lstrip("# ").strip()
        return {
            "date": _normalize_date(date),
            "type": "Other",
            "id": "",
            "title": truncate(title),
            "status": "",
            "file": str(rel_path),
        }

    return None


def generate_index(verbose: bool = False) -> int:
    """Generate INDEX.md from all artifact files. Returns count of indexed entries."""
    if not OUTPUT_DIR.is_dir():
        print(f"ERROR: Output directory not found: {OUTPUT_DIR}")
        return 0

    # Collect all .md files recursively, excluding specific files
    md_files = sorted(
        f
        for f in OUTPUT_DIR.rglob("*.md")
        if f.is_file()
        and f.name not in EXCLUDED_FILES
    )

    entries = []
    for fp in md_files:
        entry = extract_artifact(fp)
        if entry:
            entries.append(entry)
            if verbose:
                print(f"  Indexed: [{entry['type']}] {entry.get('id', '')} — {entry['title']}")
        elif verbose:
            print(f"  Skipped (no match): {fp.relative_to(OUTPUT_DIR)}")

    # Sort by date (oldest first), entries without dates go last
    entries.sort(key=lambda e: e["date"] if e["date"] else "9999-99-99")

    # Write INDEX.md
    lines = [
        "# Artifact Index",
        "",
        f"> Auto-generated by `generate_macro_index.py`. {len(entries)} artifacts indexed.",
        "> Do not edit manually — regenerate with: `python .claude/skills/scripts/generate_macro_index.py`",
        "",
        "| Date | Type | ID | Title | Status | File |",
        "|------|------|----|-------|--------|------|",
    ]

    for e in entries:
        file_link = e["file"].replace("\\", "/")
        lines.append(
            f"| {e['date']} | {e['type']} | {e['id']} | {e['title']} | {e['status']} | [{Path(e['file']).name}]({file_link}) |"
        )

    lines.append("")
    INDEX_FILE.write_text("\n".join(lines), encoding="utf-8")

    print(f"Generated {INDEX_FILE.relative_to(REPO_ROOT)} with {len(entries)} entries.")
    return len(entries)


def main():
    parser = argparse.ArgumentParser(
        description="Unified artifact index generator for OUTPUT_DIR"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show each file being processed",
    )
    args = parser.parse_args()

    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]

    count = generate_index(verbose=args.verbose)
    if count == 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
