#!/usr/bin/env python3
"""
generate_index.py — Generic output directory index generator.

Scans files in OUTPUT_DIR/<subdir>/ and produces INDEX.md with one-line summaries.
Has built-in presets for known directories (fixes, advisory-logs, user-tests).

Usage
-----
    python .claude/skills/scripts/generate_index.py --dir fixes
    python .claude/skills/scripts/generate_index.py --dir advisory-logs
    python .claude/skills/scripts/generate_index.py --dir user-tests
    python .claude/skills/scripts/generate_index.py --all

Run from the repository root.
Optional flags:
    --verbose  Show each file being processed
    --all      Regenerate indexes for all known directories
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from project_config import REPO_ROOT, get_path

OUTPUT_DIR = get_path("OUTPUT_DIR") or REPO_ROOT / "_output"


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate text to max_len, appending ellipsis if needed."""
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "\u2026"


# ---------------------------------------------------------------------------
# Preset: fixes
# Header: # DONE | datetime | Fix NNNN | PREFIX-SCOPE | datetime | title
# or:     ## DONE | datetime | N | PREFIX-SCOPE | datetime | title
# ---------------------------------------------------------------------------
_FIX_HEADER_RE = re.compile(
    r"^#{1,2}\s+(?:DONE\s*\|\s*[\d\-: ]+\s*\|\s*)?"
    r"(?:Fix\s+)?(\d+)\s*\|\s*(\S+)\s*\|\s*([\d\-: ]+)\s*\|\s*(.+)",
    re.IGNORECASE,
)


def extract_fix(filepath: Path) -> dict | None:
    """Extract fix summary from a fix file."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    for line in text.split("\n")[:5]:
        line = line.strip()
        if not line.startswith("#"):
            continue
        m = _FIX_HEADER_RE.match(line)
        if m:
            return {
                "id": m.group(1).strip().zfill(4),
                "prefix_scope": m.group(2).strip(),
                "date": m.group(3).strip(),
                "title": truncate(m.group(4).strip().rstrip("|").strip()),
                "status": "DONE" if "DONE" in line.upper() else "OPEN",
            }
    return None


# ---------------------------------------------------------------------------
# Preset: advisory-logs
# Header: # Advisory NNNN | PREFIX-SCOPE | datetime | title
# ---------------------------------------------------------------------------
_ADVISORY_HEADER_RE = re.compile(
    r"^#\s+Advisory\s+(\d+)\s*\|\s*(\S+)\s*\|\s*([\d\-: UTC]+)\s*\|\s*(.+)",
    re.IGNORECASE,
)


def extract_advisory(filepath: Path) -> dict | None:
    """Extract advisory summary from an advisory file."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    for line in text.split("\n")[:5]:
        line = line.strip()
        if not line.startswith("#"):
            continue
        m = _ADVISORY_HEADER_RE.match(line)
        if m:
            return {
                "id": m.group(1).strip().zfill(4),
                "prefix_scope": m.group(2).strip(),
                "date": m.group(3).strip(),
                "title": truncate(m.group(4).strip().rstrip("|").strip()),
                "status": "DONE",
            }
    return None


# ---------------------------------------------------------------------------
# Preset: user-tests
# Header: #### AN. title (Plan NN — PREFIX)
# ---------------------------------------------------------------------------
_USERTEST_HEADER_RE = re.compile(
    r"^#{1,4}\s+A?(\d+)\.?\s+(.+?)(?:\s*\((?:Plan|Fix)\s+(\d+).*?\))?\s*$",
    re.IGNORECASE,
)


def extract_usertest(filepath: Path) -> dict | None:
    """Extract user-test summary from a user-test file."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    for line in text.split("\n")[:5]:
        line = line.strip()
        if not line.startswith("#"):
            continue
        m = _USERTEST_HEADER_RE.match(line)
        if m:
            return {
                "id": m.group(1).strip().zfill(4),
                "prefix_scope": "",
                "date": "",
                "title": truncate(m.group(2).strip()),
                "status": "DONE",
            }
    return None


# ---------------------------------------------------------------------------
# Preset registry
# ---------------------------------------------------------------------------
PRESETS = {
    "fixes": {
        "extractor": extract_fix,
        "file_prefix": "fix-",
        "display_name": "Fix Index",
    },
    "advisory-logs": {
        "extractor": extract_advisory,
        "file_prefix": "advisory-",
        "display_name": "Advisory Index",
        "exclude_pattern": re.compile(r"^advisory-qa-"),
    },
    "user-tests": {
        "extractor": extract_usertest,
        "file_prefix": "usertest-",
        "display_name": "User Test Index",
    },
}


def generate_dir_index(subdir: str, verbose: bool = False) -> int:
    """Generate INDEX.md for a specific OUTPUT_DIR subdirectory. Returns entry count."""
    target_dir = OUTPUT_DIR / subdir
    if not target_dir.is_dir():
        print(f"ERROR: Directory not found: {target_dir}")
        return 0

    preset = PRESETS.get(subdir)
    if not preset:
        print(f"ERROR: No preset for directory '{subdir}'. Known presets: {', '.join(PRESETS.keys())}")
        return 0

    extractor = preset["extractor"]
    file_prefix = preset["file_prefix"]
    display_name = preset["display_name"]
    exclude_pattern = preset.get("exclude_pattern")

    index_file = target_dir / "INDEX.md"

    # Collect matching files
    files = sorted(
        f
        for f in target_dir.iterdir()
        if f.is_file()
        and f.suffix == ".md"
        and f.name.startswith(file_prefix)
        and f.name != "INDEX.md"
        and (exclude_pattern is None or not exclude_pattern.match(f.name))
    )

    summaries = []
    for fp in files:
        summary = extractor(fp)
        if summary:
            summaries.append(summary)
            if verbose:
                print(f"  Indexed: {summary['id']} — {summary['title']}")
        elif verbose:
            print(f"  Skipped (no header): {fp.name}")

    summaries.sort(key=lambda s: s["id"])

    # Write INDEX.md
    lines = [
        f"# {display_name}",
        "",
        f"> Auto-generated by `generate_index.py`. {len(summaries)} entries indexed.",
        f"> Do not edit manually — regenerate with: `python .claude/skills/scripts/generate_index.py --dir {subdir}`",
        "",
        "| ID | Date | Prefix-Scope | Title | Status |",
        "|----|------|-------------|-------|--------|",
    ]

    for s in summaries:
        lines.append(
            f"| {s['id']} | {s['date']} | {s['prefix_scope']} | {s['title']} | {s['status']} |"
        )

    lines.append("")
    index_file.write_text("\n".join(lines), encoding="utf-8")

    print(f"Generated {index_file.relative_to(REPO_ROOT)} with {len(summaries)} entries.")
    return len(summaries)


def main():
    parser = argparse.ArgumentParser(
        description="Generic output directory index generator"
    )
    parser.add_argument(
        "--dir", "-d",
        help=f"Subdirectory of OUTPUT_DIR to index. Known presets: {', '.join(PRESETS.keys())}",
    )
    parser.add_argument(
        "--all", "-a", action="store_true",
        help="Regenerate indexes for all known directories",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show each file being processed",
    )
    args = parser.parse_args()

    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    if not args.dir and not args.all:
        parser.error("Either --dir or --all is required")

    total = 0
    if args.all:
        for subdir in PRESETS:
            count = generate_dir_index(subdir, verbose=args.verbose)
            total += count
        print(f"\nTotal: {total} entries indexed across {len(PRESETS)} directories.")
    else:
        total = generate_dir_index(args.dir, verbose=args.verbose)

    if total == 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
