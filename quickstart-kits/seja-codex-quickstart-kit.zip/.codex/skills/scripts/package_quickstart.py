#!/usr/bin/env python3
"""
package_quickstart.py — Package project-independent .codex resources into a
reusable quickstart zip for bootstrapping new projects.

Included:
  - All skill SKILL.md files (.codex/skills/<name>/SKILL.md)
  - All skill UI metadata (.codex/skills/<name>/agents/openai.yaml)
  - Agent-agnostic references (.agent-resources/general-*.md, general-*/*.md)
  - Template references (.agent-resources/template-*.md, template-*.json)
  - Validation scripts (.codex/skills/scripts/*.py)
  - Agent definitions (.codex/agents/*.md)
  - Rule definitions (.codex/rules/*.md)
  - Framework metadata (.codex/README.md, .codex/CHEATSHEET.md, .codex/CHANGELOG.md, .codex/skills/VERSION)

Excluded:
  - .agent-resources/project-*.md (project-specific, generated from templates)
  - repo-local host settings (managed outside the Codex project tree)
"""

import sys
import zipfile
from pathlib import Path


def find_project_root() -> Path:
    """Walk up from this script to find the directory containing .codex/."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".codex").is_dir():
            return current
        current = current.parent
    print("ERROR: Could not find project root (no .codex/ directory found).")
    sys.exit(1)


def collect_files(root: Path, claude_dir: Path) -> list[Path]:
    """Collect all project-independent files under .codex/ and .agent-resources/."""
    files: list[Path] = []

    # 1. Skill definitions and UI metadata: .codex/skills/<name>/SKILL.md + agents/openai.yaml
    skills_dir = claude_dir / "skills"
    if skills_dir.is_dir():
        for skill_dir in sorted(skills_dir.iterdir()):
            if skill_dir.is_dir() and skill_dir.name != "scripts":
                skill_file = skill_dir / "SKILL.md"
                metadata_file = skill_dir / "agents" / "openai.yaml"
                if skill_file.is_file():
                    files.append(skill_file)
                if metadata_file.is_file():
                    files.append(metadata_file)

    # 2. Agent-agnostic resources: .agent-resources/
    #    - general-*.md and general-*/*.md (shared references)
    #    - template-*.md and template-*.json (quickstart templates)
    #    Excludes project-*.md (generated per-project by $quickstart)
    agent_resources_dir = root / ".agent-resources"
    if agent_resources_dir.is_dir():
        for ref_entry in sorted(agent_resources_dir.iterdir()):
            if ref_entry.is_file():
                name = ref_entry.name
                if name.startswith("project-") or name == "template-settings.json":
                    continue  # project-specific or settings template, skip
                if name.endswith(".md") or name.endswith(".json"):
                    files.append(ref_entry)
            elif ref_entry.is_dir() and ref_entry.name.startswith("general-"):
                # Include all .md files in general-* subdirectories
                for sub_file in sorted(ref_entry.iterdir()):
                    if sub_file.is_file() and sub_file.suffix == ".md":
                        files.append(sub_file)

    # 3. Validation scripts: .codex/skills/scripts/*.py
    scripts_dir = claude_dir / "skills" / "scripts"
    if scripts_dir.is_dir():
        for script_file in sorted(scripts_dir.iterdir()):
            if script_file.is_file() and script_file.suffix == ".py":
                files.append(script_file)

    # 4. Agent definitions: .codex/agents/*.md
    agents_dir = claude_dir / "agents"
    if agents_dir.is_dir():
        for agent_file in sorted(agents_dir.iterdir()):
            if agent_file.is_file() and agent_file.suffix == ".md":
                files.append(agent_file)

    # 5. Rule definitions: .codex/rules/*.md
    rules_dir = claude_dir / "rules"
    if rules_dir.is_dir():
        for rule_file in sorted(rules_dir.iterdir()):
            if rule_file.is_file() and rule_file.suffix == ".md":
                files.append(rule_file)

    # 6. Framework metadata
    for extra in (
        claude_dir / "README.md",
        claude_dir / "CHEATSHEET.md",
        claude_dir / "CHANGELOG.md",
        claude_dir / "skills" / "VERSION",
    ):
        if extra.is_file():
            files.append(extra)

    return files


def main() -> None:
    root = find_project_root()
    claude_dir = root / ".codex"
    kits_dir = root / "seja-public" / "quickstart-kits"
    kits_dir.mkdir(parents=True, exist_ok=True)
    zip_path = kits_dir / "seja-codex-quickstart-kit.zip"

    files = collect_files(root, claude_dir)

    if not files:
        print("ERROR: No files found to package.")
        sys.exit(1)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in files:
            arcname = file_path.relative_to(root).as_posix()
            zf.write(file_path, arcname)

    size_kb = zip_path.stat().st_size / 1024
    print(f"OK: {zip_path.name}")
    print(f"  Files: {len(files)}")
    print(f"  Size:  {size_kb:.1f} KB")
    print(f"  Path:  {zip_path}")
    print()
    print("Contents:")
    for f in files:
        print(f"  {f.relative_to(root).as_posix()}")


if __name__ == "__main__":
    main()
