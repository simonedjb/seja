# SPN — Sponsors

> VPs, product directors, and clients commissioning projects that use the framework.

## Core Question

"What am I paying for? How does this improve outcomes?"

## Roles

- VP of Product / VP of Engineering
- Product director
- Client stakeholder / Project commissioner
- Budget owner
- Program manager

## Communication Content

### Essential (all Sponsors need)

- **Value Proposition Brief**: What the framework delivers in business terms — faster onboarding, more consistent code quality, reduced rework. One page, no technical jargon.
- **Outcome Metrics**: Measurable indicators that the framework is working. Onboarding time reduction, defect rate changes, review turnaround, developer satisfaction scores.
- **Risk Mitigation Story**: How the framework reduces project risk — structured reviews catch issues earlier, onboarding reduces bus factor, conceptual design documents preserve institutional knowledge.

### Deep-dive (load for thorough engagement or when Sponsor is the primary audience)

- **Cost of Not Doing**: What happens without structured AI-assisted development — inconsistent output, knowledge silos, repeated mistakes, slower onboarding. Concrete examples of waste the framework prevents.
- **ROI Modeling**: Template for calculating return on investment. Input variables (team size, project duration, current onboarding time) and projected savings. Conservative and optimistic scenarios.
- **Compliance Mapping**: How the framework supports compliance requirements — audit trails via QA logs, security review perspectives, accessibility review perspectives. Mapping to common standards (SOC 2, ISO 27001, WCAG).
- **Competitive Positioning**: How using the framework differentiates the team or product. Narrative for client conversations and proposals.

## Diataxis Mapping

| Content Type | Title | Notes |
|-------------|-------|-------|
| Explanation | Value proposition | Why structured AI-assisted development improves outcomes |
| How-to | Reporting template | How to generate and present framework metrics to stakeholders |
| Reference | KPI definitions | Definitions and measurement methods for all tracked indicators |

## Tone Guidance

- Business outcomes over process — sponsors care about results, not how the sausage is made.
- Concrete metrics — replace adjectives with numbers wherever possible. "Faster" becomes "3 days instead of 10."
- Executive-friendly — short paragraphs, bullet points, visual summaries. Assume the reader has 5 minutes.
- Honest about investment — state the cost in time and attention required, then show the payoff.
