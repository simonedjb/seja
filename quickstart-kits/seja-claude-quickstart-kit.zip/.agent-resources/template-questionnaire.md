# TEMPLATE - PROJECT INSTANTIATION QUESTIONNAIRE

> **Questionnaire version:** 1
> **Last updated:** 2026-03-25
>
> **Purpose:** Answer these questions to generate all 7 `project-*` reference files from the `template-*` templates. An agent can read your completed answers and produce the full set of project-specific references.
>
> **How to use:**
> 1. Start with **Section 0 (Quick Start)** — these 8 answers are enough to generate a minimal skeleton.
> 2. Work through **Sections 1–7** at your own pace for full coverage.
> 3. For technical questions, choose from the provided alternatives or write your own.
> 4. Write `N/A` or `Skip` for sections that don't apply to your stack.
> 5. When done, give this file to an agent with the instruction: *"Instantiate all template-\* files into project-\* files using the answers in this questionnaire."*
>
> **Alternative:** For a faster workflow, use `/quickstart --generate-spec` to create a pre-fillable spec file (see `template-quickstart-spec.md`).

---

## Section 0 — Quick Start (Minimum Viable Answers)

> These 8 questions generate a working skeleton for all 7 files. You can refine later.

| # | Question | Fills | Your Answer |
|---|----------|-------|-------------|
| 0.1 | What is your project's display name? | `{{PROJECT_NAME}}` | |
| 0.2 | What does your application do? (1–2 sentences) | Conceptual design intro | |
| 0.3 | What is your backend language/framework? | Backend standards scope | |
| 0.4 | What is your frontend language/framework? | Frontend standards scope | |
| 0.5 | What database will you use? | Backend DB sections | |
| 0.6 | What are your primary and secondary UI languages? (e.g., en-US, pt-BR) | `{{PRIMARY_LOCALE}}`, `{{SECONDARY_LOCALE}}` | |
| 0.7 | Name your generated-artifacts output folder (e.g., `_output`, `_generated`) | `{{OUTPUT_DIR}}` | |
| 0.8 | Name your backend and frontend source directories (e.g., `backend`, `frontend`) | `{{BACKEND_DIR}}`, `{{FRONTEND_DIR}}` | |

---

## Section 1 — Project Conventions (`template-conventions.md`)

> Fills: `project-conventions.md` — the master variable file that all other references depend on.

**1.1** Project display name?
> *Fills `{{PROJECT_NAME}}`.*

Answer:

**1.2** Root directory for generated artifacts (plans, scripts, inventories, advisories)?
> *Fills `{{OUTPUT_DIR}}`. This folder will be created at the repo root. Choose a name that won't conflict with source directories.*

Answer:

**1.3** Backend source root directory?
> *Fills `{{BACKEND_DIR}}`. Typically `backend`, `server`, `api`, or `src`.*

Answer:

**1.4** Frontend source root directory?
> *Fills `{{FRONTEND_DIR}}`. Typically `frontend`, `client`, `web`, or `src`.*

Answer:

**1.5** Do you have additional source directories (e.g., `mobile`, `shared`, `libs`)? If so, list them with a short description.

Answer:

---

## Section 2 — Conceptual Design (`template-conceptual-design.md`)

> Fills: `project-conceptual-design-as-is.md` and `project-conceptual-design-to-be.md` — describes WHAT your system is (current and target state), not HOW it's built.

**2.1** What does your platform do? Who is it for? What problem does it solve? (2–3 paragraphs)

Answer:

**2.2** Does your platform follow a specific design philosophy or methodology? (e.g., gamification, collaborative filtering, evidence-based design)

Answer:

**2.3** What are your main entities and their hierarchy? List them from top-level container down to leaf-level content.
> *Example: Organization → Project → Task → Comment*

Answer:

**2.4** For each entity above, briefly describe:
- What it represents
- Visibility/access rules (public, private, role-based)
- Ownership model (who creates it, who can delete it)
- Soft delete behavior (yes/no)

Answer:

**2.5** Are there any domain-specific concepts unique to your application? (e.g., workflows, scoring systems, annotation types, approval chains)

Answer:

**2.6** What permission levels does your system need?

**System-level roles** (e.g., guest, member, admin):

| Role | Capabilities |
|------|-------------|
| | |

**Resource-level access** (e.g., per-project, per-organization — if applicable):

| Access Level | Capabilities |
|-------------|-------------|
| | |

**2.7** Does your application support content authoring? If so:
- How is authorship tracked?
- Can content be attributed to non-system users (e.g., imported authors)?
- Is there a mention/notification system?

Answer:

**2.8** Does your application support import/export? If so, list the formats and their purpose.

Answer:

**2.9** Is this a greenfield project (as-is = to-be) or an evolving product with a gap between current and target design?
> *Determines whether quickstart populates `project-conceptual-design-as-is.md` and `project-conceptual-design-to-be.md` identically or differently.*

Answer: (greenfield / evolving)

**2.10** What is the initial metacommunication message? Summarize what the designer intends to communicate to the user about who they are, what they can do, and why.
> *Feeds `project-metacomm-to-be.md`.*

Answer:

**2.11** Describe your target user community: language, geography, domain expertise.

Answer:

**2.12** What are your domain-driven validation limits? (e.g., title max 200 chars because of academic citation standards)
> *List field names, min/max values, and the domain rationale for each.*

| Field | Min | Max | Rationale |
|-------|-----|-----|-----------|
| | | | |

---

## Section 3 — Frontend Standards (`template-frontend-standards.md`)

> Fills: `project-frontend-standards.md` — architectural and design conventions for the frontend.

### Framework Choices

**3.1** Which frontend framework will you use?
> *Fills overall frontend architecture. Choose one:*

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **React** | Largest ecosystem, most libraries/tooling, strong hiring pool | JSX learning curve, no built-in routing/state | **Recommended** for most web apps |
| **Vue** | Gentler learning curve, good docs, built-in reactivity | Smaller ecosystem than React, fewer enterprise patterns | Good for smaller teams or rapid prototyping |
| **Svelte/SvelteKit** | Minimal boilerplate, compiled output (smaller bundles) | Smaller ecosystem, fewer enterprise patterns, less hiring pool | Good for performance-critical or small-team projects |
| **Angular** | Full-featured framework (routing, forms, DI built-in), TypeScript-first | Steeper learning curve, heavier, opinionated | Good for large enterprise teams with Angular experience |

Answer:

**3.2** Which build tool?
> *Affects dev server, bundling, and plugin ecosystem.*

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Vite** | Fastest dev server, native ESM, great plugin ecosystem | Newer, some edge cases with legacy deps | **Recommended** for new projects |
| **Next.js** | SSR/SSG built-in, file-based routing, Vercel integration | React-only, opinionated, heavier | Best if you need SSR/SSG |
| **Webpack** | Most mature, handles any edge case | Slower dev server, complex config | Only if migrating an existing Webpack project |

Answer:

**3.3** Which CSS framework/approach?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Tailwind CSS** | Utility-first, fast prototyping, consistent design, small production CSS | Class verbosity in markup, learning curve | **Recommended** for most projects |
| **CSS Modules** | Scoped styles, familiar CSS syntax, no runtime cost | No design system out of the box, more files | Good if team prefers traditional CSS |
| **styled-components** | CSS-in-JS, dynamic styling, co-located with components | Runtime cost, bundle size, React-specific | Good for highly dynamic theming |
| **Plain CSS / SCSS** | No dependencies, full control | No scoping, harder to maintain at scale | Only for very small projects |

Answer:

**3.4** Which state management approach?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **React Context + hooks** | No extra dependencies, built into React, simple for most apps | Performance issues with frequent updates, no devtools | **Recommended** for apps with <10 global state values |
| **Zustand** | Tiny (1KB), simple API, good devtools, no boilerplate | Less structured than Redux | Good for medium complexity |
| **Redux Toolkit** | Mature, excellent devtools, structured patterns | Boilerplate, steeper learning curve | Good for large apps with complex state |
| **Jotai / Recoil** | Atomic state model, fine-grained reactivity | Newer, smaller ecosystem | Good for apps with many independent state atoms |

Answer:

**3.5** Which data fetching/caching library?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **TanStack Query** | Automatic caching, background refetch, optimistic updates, devtools | Learning curve for cache invalidation | **Recommended** for any app with REST/GraphQL APIs |
| **SWR** | Simpler API than TanStack Query, Vercel-maintained | Fewer features (no mutations, no devtools) | Good for simpler data-fetching needs |
| **Manual (useEffect + fetch)** | No dependencies, full control | No caching, stale data, boilerplate | Only for very simple apps or learning |

Answer:

**3.6** Which HTTP client?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Axios** | Interceptors, request/response transforms, wide adoption | 13KB bundle, third-party dependency | **Recommended** for apps needing interceptors (auth, CSRF, error normalization) |
| **fetch (native)** | Zero dependencies, built into all browsers | No interceptors, manual JSON parsing, verbose error handling | Good for simple apps or when bundle size is critical |
| **ky** | Tiny (3KB), modern fetch wrapper, retries | Smaller ecosystem | Good middle ground |

Answer:

**3.7** Which rich text editor? (Skip if not needed)

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Lexical** | Meta-maintained, extensible, good React support, small bundle | Steeper learning curve, newer | **Recommended** for new projects needing rich text |
| **TipTap** | Great DX, extensive extensions, ProseMirror-based | Larger bundle, some features behind paywall | Good for content-heavy apps |
| **Quill** | Simple setup, good for basic rich text | Less extensible, older architecture | Good for simple use cases |
| **None** | Simpler codebase | No rich text capability | Skip this section |

Answer:

**3.8** Which router? (if React)

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **React Router v7** | Most mature, large ecosystem, file-based routing option | API churn between versions | **Recommended** for React apps |
| **TanStack Router** | Type-safe, search params validation, newer design | Newer, smaller ecosystem | Good for TypeScript-heavy projects |

Answer:

### Design Choices

**3.9** What are your brand colors?
> *Provide semantic names and hex values. Minimum: primary, secondary.*

| Token | Hex | Usage |
|-------|-----|-------|
| `primary` | | Main actions, headings |
| `secondary` | | Links, secondary actions |

**3.10** What fonts will you use?
> *Provide font family names for sans-serif (UI) and serif (content, if applicable).*

| Token | Font Family | Usage |
|-------|------------|-------|
| `sans` | | Primary UI font |
| `serif` | | Content font (if applicable) |

**3.11** Will your application support dark mode?

Answer: (yes / no / later)

**3.12** What WCAG level do you target?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **WCAG 2.1 AA** | Industry standard, achievable, covers most needs | Misses some enhanced requirements | **Recommended** minimum for all projects |
| **WCAG 2.1 AAA** | Best accessibility, higher contrast, more keyboard support | Harder to achieve, some design constraints | Recommended for public/government/education platforms |

Answer:

**3.13** List the React Context providers your app will need:
> *Common contexts: Auth, Theme, Notifications. Add domain-specific ones.*

| Context | Purpose | Hook |
|---------|---------|------|
| `AuthContext` | User session | `useAuth()` |
| | | |

**3.14** What reusable components will your app start with?
> *Common: AlertMessage, Modal, DoubleConfirmationModal, Toast, Breadcrumb, ErrorBoundary. Add domain-specific ones.*

Answer:

---

## Section 4 — Backend Standards (`template-backend-standards.md`)

> Fills: `project-backend-standards.md` — architectural conventions for the backend.

### Framework Choices

**4.1** Which backend framework?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Flask** | Lightweight, flexible, easy to learn, large ecosystem | No built-in ORM/auth/admin, more manual setup | **Recommended** for small-to-medium APIs |
| **Django** | Batteries-included (ORM, admin, auth, migrations), mature | Heavier, more opinionated, monolithic | Good for data-heavy apps needing admin UI |
| **FastAPI** | Async, auto-generated docs, Pydantic validation, modern Python | Younger ecosystem, async complexity | Good for high-throughput APIs or microservices |
| **Express/NestJS** | JavaScript/TypeScript fullstack, large ecosystem | Node.js event loop quirks, callback patterns (Express) | Good for TypeScript fullstack teams |

Answer:

**4.2** Which ORM / database layer?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **SQLAlchemy** | Most powerful Python ORM, flexible, supports raw SQL | Complex, steeper learning curve | **Recommended** for Flask or FastAPI |
| **Django ORM** | Integrated with Django, simple, great migrations | Django-only, less flexible for complex queries | Use with Django |
| **Prisma** | Type-safe, great DX, auto-generated client | Node.js only, less mature for complex queries | Use with Express/NestJS |
| **TypeORM / Drizzle** | TypeScript-native, decorators or schema-based | TypeORM has known issues at scale; Drizzle is newer | Use with NestJS |

Answer:

**4.3** Which database?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **PostgreSQL** | Feature-rich, JSONB, full-text search, rock-solid | Slightly more setup than SQLite | **Recommended** for production apps |
| **MySQL/MariaDB** | Wide hosting support, familiar | Fewer advanced features than Postgres | Good if hosting requires it |
| **SQLite** | Zero setup, embedded, great for dev/testing | Single-writer, no network access, limited concurrent writes | Good for prototyping and unit tests only |
| **MongoDB** | Flexible schema, horizontal scaling | No ACID transactions (by default), query limitations | Good for document-centric or high-write-volume apps |

Answer:

**4.4** Which migration tool?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Alembic** | SQLAlchemy-native, auto-generates from models, flexible | Manual for complex migrations | **Recommended** with SQLAlchemy |
| **Django Migrations** | Auto-generated, integrated, easy | Django-only | Use with Django |
| **Prisma Migrate** | Type-safe, declarative schema | Prisma-only | Use with Prisma |
| **Manual SQL** | Full control, no abstraction | Error-prone, no rollback tracking | Not recommended |

Answer:

**4.5** Which validation library?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Marshmallow** | Mature, flexible, great with Flask/SQLAlchemy | Separate from ORM, boilerplate | **Recommended** for Flask |
| **Pydantic** | Built into FastAPI, Python type hints, fast | FastAPI-centric, less flexible for complex nesting | Use with FastAPI |
| **Django Forms / Serializers** | Integrated, DRF serializers are powerful | Django-only | Use with Django/DRF |
| **Zod / Joi** | TypeScript/JavaScript-native, composable | Node.js only | Use with Express/NestJS |

Answer:

**4.6** Which authentication approach?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **JWT (HttpOnly cookies)** | Stateless, scalable, secure cookie storage | Token revocation requires blocklist, cookie setup complexity | **Recommended** for SPAs with same-origin API |
| **JWT (localStorage)** | Simple frontend implementation | XSS-vulnerable, tokens accessible to JavaScript | Not recommended for production |
| **Session-based** | Simple, built into most frameworks, easy revocation | Server-side storage, scaling requires session store | Good for traditional server-rendered apps |
| **OAuth2 / OpenID Connect** | Delegated auth, social login, enterprise SSO | Complex setup, third-party dependency | Good when integrating with identity providers |

Answer:

**4.7** What JWT token expiry times?
> *Fills `{{access_token_expiry}}`, `{{refresh_token_expiry}}`.*

- Access token: (e.g., 1 hour)
- Refresh token: (e.g., 7 days)

Answer:

**4.8** What is the default rate limit?
> *Fills `{{default_rate_limit}}`.*

Answer: (e.g., 200/minute)

**4.9** List your initial backend extensions/libraries:
> *Common: ORM, JWT auth, migrations, rate limiter, i18n, CORS, validation, API docs.*

| Extension | Purpose |
|-----------|---------|
| | |

**4.10** Will your backend serve file uploads? If yes, what are the size limits and allowed formats?

Answer:

**4.11** Will your backend support import/export? If yes, what formats?

Answer:

---

## Section 5 — Testing Standards (`template-testing-standards.md`)

> Fills: `project-testing-standards.md` — testing conventions across all layers.

**5.1** Which backend test framework?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **pytest** | Powerful fixtures, plugins, parametrize, most popular Python | Some magic with fixtures/discovery | **Recommended** for Python backends |
| **unittest** | Built into Python, no extra dependency | Verbose, less ergonomic | Only if avoiding dependencies |
| **Jest** | Built-in mocking, snapshots, wide JS adoption | Node.js only | Use with Express/NestJS |

Answer:

**5.2** Which frontend test framework?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Vitest** | Vite-native, fast, compatible with Jest API | Newer, some edge cases | **Recommended** with Vite |
| **Jest** | Most mature, largest ecosystem, snapshots | Slower than Vitest, CJS-native | Good for Webpack projects |

Answer:

**5.3** Which E2E test framework?

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| **Playwright** | Multi-browser, auto-wait, codegen, trace viewer | Larger install size | **Recommended** for new projects |
| **Cypress** | Great DX, time-travel debugging, dashboard | Chromium-focused, no multi-tab, paid features | Good for simpler E2E needs |
| **None** | Simpler setup | No E2E coverage | Skip E2E section |

Answer:

**5.4** Will you use a separate integration test suite against a real database? (yes / no)

Answer:

**5.5** What is your E2E base URL?
> *Fills `{{base_url}}`.*

Answer: (e.g., `http://localhost:3000`)

---

## Section 6 — i18n Standards (`template-i18n-standards.md`)

> Fills: `project-i18n-standards.md` — internationalization conventions.

**6.1** How many languages will your application support at launch?
> *List RFC 5646 codes (e.g., `en-US`, `pt-BR`, `fr-FR`, `de-DE`).*

| Locale Code | Language | Role |
|------------|----------|------|
| | | Primary (UI default) |
| | | Secondary |
| | | (additional, if any) |

**6.2** What is the backend's default locale for error messages?
> *Fills `{{BACKEND_DEFAULT_LOCALE}}`. Often differs from frontend default (e.g., backend defaults to `en-US` for developer-facing logs while frontend defaults to the community's primary language).*

Answer:

**6.3** Why did you choose these defaults?
> *Helps document the rationale in the i18n standards file.*

- Frontend default rationale:
- Backend default rationale:

**6.4** Does your application send localized emails? (yes / no)

Answer:

**6.5** Do any domain entities store translations in the database? (e.g., category names in multiple languages)
> *If yes, list the entities and their translatable fields.*

Answer:

---

## Section 7 — Security Checklists (`template-security-checklists.md`)

> Fills: `project-security-checklists.md` — security checklists are mostly generic; customize the constants table.

**7.1** List your validation constants with their values:
> *These will populate the Quick Reference table and must stay in sync between backend and frontend.*

| Field | Backend Constant | Frontend Constant | Value |
|-------|-----------------|-------------------|-------|
| Login length min | | | |
| Login length max | | | |
| Password min | | | |
| Name max | | | |
| Email max | | | |
| (add more) | | | |

**7.2** Where are validation constants defined?
> *Fills `{{backend_constants_path}}` and `{{frontend_constants_path}}`.*

- Backend:
- Frontend:

**7.3** Are there any checklists (A–N) that don't apply to your project? List them.
> *Example: "Checklist B (File Upload) — N/A, no file uploads" or "Checklist L (SSRF) — N/A, no user-supplied URLs"*

Answer:

**7.4** Do you have any project-specific security requirements not covered by checklists A–N? (e.g., compliance certifications, data residency, audit logging requirements)

Answer:

---

## Post-Questionnaire Checklist

After completing all sections:

- [ ] Section 0 (Quick Start) is fully filled — enough for a skeleton
- [ ] Section 1 (Conventions) defines all directory paths
- [ ] Section 2 (Conceptual Design) describes entities, permissions, metacommunication, and greenfield/evolving status
- [ ] Section 3 (Frontend) has framework and design choices
- [ ] Section 4 (Backend) has framework and architecture choices
- [ ] Section 5 (Testing) has framework choices per layer
- [ ] Section 6 (i18n) has locale codes and defaults
- [ ] Section 7 (Security) has validation constants

**Next step:** Give this file to an agent with:
> *"Read template-questionnaire.md and instantiate all template-\* files in `.agent-resources` into corresponding project-\* files using my answers."*

---

## Version History

> This section tracks changes to the questionnaire format. When a spec file's `version` field differs from the current `questionnaire_version`, the agent uses this history to identify new, changed, or removed fields and offer migration.

| Version | Date       | Changes                                                                                                                      |
|---------|------------|------------------------------------------------------------------------------------------------------------------------------|
| 1       | 2026-03-25 | Initial versioned release. Sections 0-7 with all fields. Companion spec file format (template-quickstart-spec.md) introduced |
