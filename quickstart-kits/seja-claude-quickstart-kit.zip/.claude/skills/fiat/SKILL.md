---
name: fiat
description: "Make and execute a plan to add a feature, fix a bug, or refactor code."
argument-hint: <brief> [--manual] [--max-iterations N]
disable-model-invocation: true
metadata:
  last-updated: 2026-03-27 12:00:00
  version: 1.0.0
  category: planning
  context_budget: standard
  depends:
    - make-plan
    - execute-plan
  references: []
---

## Quick Guide

**What it does**: A shortcut that creates a plan AND executes it in one go. Use when you are confident about what you want and do not need to review the plan separately.

**Example**:
> You: /fiat Fix the broken link on the settings page that points to the old help center URL
> Agent: Analyzes the issue, creates a plan, executes the fix, and runs quality checks — all in one pass. Reports what changed.

**When to use**: You have a straightforward task (bug fix, small feature, quick refactor) and trust the agent to plan and execute without a separate review step.

# Fiat

If there are no arguments, ask for the brief.

## Definitions

Unless otherwise specified, consider `${PLANS_DIR}/plan-<id>-<truncated short title slug>.md` (see project-conventions.md) as the plan file, where <id> is a sequential number, zero-padded to 4 characters

## Flags

- `--manual`: Pass through to `/execute-plan` to use manual mode (all steps in current context instead of fresh subagents). Use for small plans or when interactive confirmation is needed.
- `--max-iterations N`: Pass through to `/execute-plan` to set the iteration cap (default: 20). Only meaningful in auto mode (the default).
- `--dry-run`: Pass through to `/execute-plan`. Shows the planned changes for each step without applying them. Useful for previewing what would happen before committing to execution.

## Skill-specific Instructions

> **Note:** References are loaded by child skills (`make-plan` and `execute-plan`). Fiat intentionally declares no references to avoid double-loading.

1. Run /pre-skill "fiat" $ARGUMENTS[0] to add general instructions to the context window.

2. Run /make-plan $ARGUMENTS[0] to plan, saving the plan to a plan file in the format specified in the make-plan skill without asking for confirmation and outputting the <plan id>.

3. Run /execute-plan <plan id> [--manual] [--max-iterations N] to execute the plan, also without asking for confirmation (unless it is bound to have catastrophic consequences). Pass through `--manual` and `--max-iterations` flags if they were provided in the original arguments.
